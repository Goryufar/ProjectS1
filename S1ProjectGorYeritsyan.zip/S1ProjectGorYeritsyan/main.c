#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/// Car struct which will contain information from list.txt file and store it in here
struct car{
    int vinNum; /// serial number it shouldnt repeat with other cars
    char Modelname[50];   // this is the name For example Tesla mode X
    int weight; // weight atribut 
    int engineMaxTemp; // higher temperature will go the more problems you will have
    int brakingProblem;//0 false 1 true
    int batteryProblem;// 0 false 1 true
};

/// this is the struct where the problems will be stored
struct problemCarS{
    int id; /// same with VinNum
    int weightProblem; // <2500 3000> bad
    int overheating; /// >150 bad
    int brakingProblem; // true false 
    int batteryProblem; // true false
};

// this is the Prototype of the functions 

void qualityCheck(struct car cars[], int size);
void carPrint(struct car cars[], int size);
void fileRead(struct car cars[], int *size ,char keyword[]);
void addProblemToFile(FILE *file, int id, const char *carProblems[], int *problem_ids,int size);
void help();
void editData(struct car cars[], int size, struct problemCarS problems[], int problemSize) ;
void readProblematicFile(struct problemCarS problematicCars[], int *problematicCount);
void resetProblematicData(int *problematicCount);
void resetListSize(int *count);
void Save();
void addEntry(struct car cars[] , int *size );
void deleteEntryByVINNUM( struct car cars[],int vinToDelete);
void Hello();

/// most important function where our program will strat and end 
int main()
{
    Hello(); // print our greetings
    struct car cars[500];  // making struct of cars it will have max 500 cars we dont need more thats why we dont allocate dinamic memorry
    struct problemCarS problematicCars[500]; // we have maximum 500 cars and our problematic car will be at most 500
    char keyword[50]; // this is helping cherecters to compare keyword from the file
    int count = 0; // list of cars counter help us to know how many cars we read from file
    int problematicCount = 0; // save with problemati_cars.txt
    char input[10]; // this is our functions input for example we input help it will do help function
    int vinDeleteInput =0; // this is input number when we delete undesired car and we just need to say viNum
    fileRead(cars,&count,keyword); // first time reads list.txt file and fills all the variables to our cars struct     

    do{ /// does function at least once for example we can input exit and our console will close
          printf("Input for example |diagnostics|, |print| or |exit| "); 
            scanf("%s",input); // scans the input from user 

        if (strcmp(input, "exit") == 0 || strcmp(input, "close") == 0 ) { // compares data to do the function
            break;  // Exit the loop if the user inputs "exit"
        }
        else if(strcmp(input, "quality") == 0 || strcmp(input, "diagnostics") == 0){
            qualityCheck(cars,count);
            // does diagnostics 
        }
        else if(strcmp(input, "print") == 0 || strcmp(input, "Print") == 0 ){
              carPrint(cars,count);
                // prints all the elements of the list.txt file which already is in cars struct 
        }
         else if(strcmp(input, "edit") == 0 || strcmp(input, "Edit") == 0 ){
            
            
            resetProblematicData(&problematicCount); // make counter zero to not go outside of the boundaries 
            readProblematicFile(problematicCars, &problematicCount); // reads from problematic_cars.txt file and fils problematic cars struct
            editData(cars,count,problematicCars,problematicCount); // asks from user what car to edit and if it has at least one problem it will appear the type of the problem and will ask to user input new data
        }
        else if(strcmp(input, "help") == 0 || strcmp(input, "?") == 0 ){
          
            help();// print all the commands
        }
         else if(strcmp(input, "save") == 0 || strcmp(input, "Save") == 0 ){
          
            Save(cars,count); // saves after edit to the list.txt file our cars struct values
        }
        else if(strcmp(input, "add") == 0 || strcmp(input, "+") == 0 ){
           addEntry(cars ,&count); // appends new car with user input
            
        }
        else if(strcmp(input, "delete") == 0 || strcmp(input, "Delete") == 0 ){
          
            printf("Input the Vinum that you want to delete ");// deletes element from list.txt and reads again
            scanf("%d",&vinDeleteInput);
            deleteEntryByVINNUM(cars,vinDeleteInput); 
            resetListSize(&count);
            fileRead(cars,&count,keyword);
        }
       
        else if(strcmp(input, "clear") == 0 ){
             system("cls"); // clears console to avoid garbage
        }
        else{
              printf("unkown comand : %s\n",input); // prints that your input was unkown if you made mistake
        }
    }while (1); // allways work untill brake the loop
  
    
     printf(" exiting .....  ");
 
    return 0; // if everything is done just closes the program
    
}
void fileRead(struct car cars[], int *size, char keyword[]) {

    FILE *fptr = fopen("list.txt", "r"); // opens file with read mode
    if (fptr == NULL) {
        perror("Error opening file"); // handles oppening error
        return;
    }

    while (fscanf(fptr, "%s", keyword) == 1) {// scans our inputed keyword if its characters the same with the one from file adds to the stuct that element

        if (strcmp(keyword, "VINNUM") == 0) {
            // Read VINUM
            fscanf(fptr, "%d", &cars[*size].vinNum); // transforms data from txt file to the struct 
        } else if (strcmp(keyword, "MODELNAME") == 0) {
            // Read ModelName
            fscanf(fptr, "%s", cars[*size].Modelname);
        } else if (strcmp(keyword, "WEIGHT") == 0) {
            // Read Weight
            fscanf(fptr, "%d", &cars[*size].weight);
        } else if (strcmp(keyword, "MaxTemp") == 0) {
            // Read Engine heating problem
            fscanf(fptr, "%d", &cars[*size].engineMaxTemp);
        } 
        else if (strcmp(keyword, "BrakeIssue") == 0) {
            // Read Brake problem
          
            fscanf(fptr, "%d", &cars[*size].brakingProblem);
           
        } 
        else if (strcmp(keyword, "BattareyProblem") == 0) {
            // Read Battarey problem
          
            fscanf(fptr, "%d", &cars[*size].batteryProblem);
            (*size)++; // adds one to counter to know the size ,we know that battareyProblem is the last property thats why our counter is here
        } 
        else {
            // Handle other keywords or invalid input
            printf("Unknown keyword: %s\n", keyword);
            break;
        }
    }

    fclose(fptr); // it is crutial to close ,not to crash our program
}
void resetListSize(int *count) {
    *count = 0; // reset list counter
}
void carPrint(struct car cars[] , int size ){
     for (int i = 0; i < size; i++) {
        // print our data to show our user
        printf("VinNum: %d, ModelName: %s , Weight: %d  ,MaxTemp: %d, BrakeIssue: %d, BatteryProblem: %d\n", cars[i].vinNum, cars[i].Modelname,cars[i].weight,cars[i].engineMaxTemp,cars[i].brakingProblem,cars[i].batteryProblem);
    }
}
void qualityCheck(struct car cars[], int size) {

    FILE *problematic = fopen("problematic_cars.txt", "w"); // opens write mode
    if (problematic == NULL) {
        perror("Error opening problematic_cars.txt");
        return;
    }

    printf("-----------------------------------------------------\n");
    printf("Diagnosis check\n");
    printf("-----------------------------------------------------\n\n");

   
    const char *carProblems[] = {"WeightProblem", "Overheating", "BrakeIssue","BatteryProblem"};// the type of the problems
    
    for (int i = 0; i < size; i++) {/// passes trough every cars struct and compare all the neccesary information
       
        printf("Car VinNum: %d\n", cars[i].vinNum);
        printf("Model Name: %s\n", cars[i].Modelname);
        int problem_ids[4] ={0};// makes problem numbers which will contain the type of the problem for example problem_ids[0] is the weight problem we add to it some number ,to compare it in the future
        int problemCount = 0;// calculates problem numbers

        if (cars[i].weight < 2500 || cars[i].weight > 3000 ) {
            // compares weight requierment if it has a problem adds counter 1 and the type of the problem with some defined number
            printf("the car has a problem with weight\n", cars[i].vinNum);

            problemCount++;
            problem_ids[0] = 1;
        }

        if (cars[i].engineMaxTemp > 150 ) {
            // does the same thing with the  maxTemp
            printf("the car engine has overheating problem\n", cars[i].vinNum);
            problemCount++;
            problem_ids[1] = 2;
        }

        
        if (cars[i].brakingProblem  == 1) {
           
            printf("the car has a problem with brakes\n", cars[i].vinNum);

            problemCount++;
            problem_ids[2] = 3;
        
        }
        if (cars[i].batteryProblem  == 1) {
           
            printf("the car has a battery problem \n", cars[i].vinNum);

            problemCount++;
            problem_ids[3] = 4;
        
        }

        if(problemCount > 0){
            addProblemToFile(problematic, cars[i].vinNum, carProblems,problem_ids,size);
            // if we have at least 1 problem pass to the addProblemtofile function our neccesary arguments

        }
        
        printf("the car has %d problems \n",problemCount);
   
        fprintf(problematic, "\n");
        printf("-----------------------------------------------------\n");
    }

    fflush(problematic);// it writes any buffered data to the associated file or device and after that closes
    fclose(problematic);
}

void addProblemToFile(FILE *file, int id, const char *carProblems[], int *problem_ids,int size) {

    fprintf(file, "VIMNUM %d ", id);/// in this function we add our problems to problematic_cars.txt

    for (int i = 0; i < 4; i++) {//4 is our problems ids size
    
        if (problem_ids[i] == 1) { // we compare the predetermined numbers if it is 1 it is weight problem
           
            fprintf(file, "PROBLEM %s, ", carProblems[0]); // weight not satisfy
            
        }
        else if (problem_ids[i] == 2) {
           
            fprintf(file, "PROBLEM %s, ", carProblems[1]); // temperatureProblem (overheating)
          
        }
        else if (problem_ids[i] == 3) {
           
            fprintf(file, "PROBLEM %s, ", carProblems[2]); // brake problem report
            break;
        }
        else if (problem_ids[i] == 4) {
           
            fprintf(file, "PROBLEM %s, ", carProblems[3]); //  BatteryProblem report
            break;
        }
    }
}
void help(){
    //print our all neccesry functions
    printf("------------------------------------------------------------------\n");
    printf(" /$$   /$$           /$$          \n");
    printf("| $$  | $$          | $$         \n");
    printf("| $$  | $$  /$$$$$$ | $$  /$$$$$$\n");
    printf("| $$$$$$$$ /$$__  $$| $$ /$$__  $$\n");
    printf("| $$__  $$| $$$$$$$$| $$| $$  | $$\n");
    printf("| $$  | $$| $$_____/| $$| $$  | $$\n");
    printf("| $$  | $$|  $$$$$$$| $$| $$$$$$$/\n");
    printf("|__/  |__/ |_______/|__/| $$____/ \n");
    printf("                        | $$      \n");
    printf("                        | $$      \n");
    printf("                        |__/      \n");
   
    printf("-------- This is the all funtions---------------------\n");
    printf("|help| or |?| : it will print all the functions descriptions  \n");
    printf("|clear| : it will clear console \n");
    printf("|print| or |Print| : it will print all elements of your car list  \n");
    printf("|qaulity| or |diagnostics| : it will check whether our cars have any problems \n");
    printf("|edit| or |Edit| : it will edit only problematic car make sure do it after diagnostics \n");
    printf("|add| or |+| : add one ellement to the list.txt file \n");
    printf("|delete| or |Delete| : remove desired ellement from the list.txt file \n");
    printf("|save| or |Save| : it will save our problematic cars new values to the inital list \n");
    printf("|exit| or |close| : exit program ( dont save problematic cars new values to the inital list) for that use Save function \n");
    printf("------------------------------------------------------------------\n");
}
void Hello(){


//hi
printf("   -           __\n");
printf(" --          ~( @\\  \\ \n");
printf("---   _________]_[__/_>________\n");
printf("     /  ____ \\ <>     |  ____  \\ \n");
printf("    =\\_/ __ \\_\\_______|_/ __ \\__D \n");
printf("________(__)_____________(__)____\n");
    printf("------------------------------------------------------------------\n");
    printf("Hello this is car manufacturing quality control\n");
    printf("Made by Gor Yeritsyan \n");
    printf("use |help| function in order to learn about all the functions\n");
    printf("------------------------------------------------------------------\n");
}
void editData(struct car cars[], int size, struct problemCarS problems[], int problemSize) {
    //initialize all the neccesary variables 
    int _input = -1;
    int newWeight = 0;
    int MaxTemp = 0;
    int brakingProblem = 0;
    int batteryProb =0;
    // ask from user what car to change (it will change only problematic once)
    printf("Input ID of the car that you want to change: ");
    if (scanf("%d", &_input) != 1) {
        printf("Invalid input for ID.\n");//error handling 
        return;
    }

    for (int i = 0; i < problemSize; i++) {

        if (problems[i].id == _input ) {// compare our input id to the problem ids

            if(problems[i].weightProblem ==1){// if it has weight problem it will ask user to input new data and will change it
                printf("Input new value for weight (from 2500 to 3000 ): ");//2500-3000 requierd data
                    if (scanf("%d", &newWeight) != 1) {
                        printf("Invalid input for weight.\n");
                        return;
                    }
           
                for(int i = 0; i < size;i++){
                   
                        if(cars[i].vinNum == _input){
                    
                        cars[i].weight = newWeight; // finds the same id and changes
                   
                    }
                }       
          

            printf("Weight updated successfully.\n");// notify user that it was succesfull


            }
             if(problems[i].overheating ==1){ // same is with other problems the good point is it will continusly ask you to change data unitl the end of the problems
                printf("Input new value for engine Max Temp (min 100 max 150): ");
                    if (scanf("%d", &MaxTemp) != 1) {
                        printf("Invalid input for problem.\n");
                        return;
                    }
                    else if(MaxTemp < 100){
                        printf("invalid input \n");
                         return;
                    }
           
                for(int i = 0; i < size;i++){
                        if(cars[i].vinNum == _input){
                    
                        cars[i].engineMaxTemp = MaxTemp;

                    }
                }       

            printf("engine updated successfully.\n");

            }
            if(problems[i].brakingProblem ==1){
                printf("Input new value for braking problem 0 or 1: ");
                    if (scanf("%d", &brakingProblem) != 1) {
                        printf("Invalid input for problem.\n");
                        return;
                    }
                    else if(brakingProblem != 0 && brakingProblem != 1 ){
                        printf("invalid input \n");
                         return;
                    }
                for(int i = 0; i < size;i++){
                        if(cars[i].vinNum == _input){
                    
                        cars[i].brakingProblem = brakingProblem;

                    }
                }       
          
            printf("brakes updated successfully.\n");

            }
            
             if(problems[i].batteryProblem ==1){
                printf("Input new value for battarey problem 0 or 1: ");
                    if (scanf("%d", &batteryProb) != 1) {
                        printf("Invalid input for problem.\n");
                        return;
                    }
                    else if(batteryProb != 0 && batteryProb != 1 ){
                        printf("invalid input \n");
                         return;
                    }
                for(int i = 0; i < size;i++){
                        if(cars[i].vinNum == _input){
                    
                        cars[i].batteryProblem = batteryProb;

                    }
                }       
          
            printf("batteryProb updated successfully.\n");

            }
        
            
             return; // returns we dont need make any interations
        }
    }

    // If the loop completes, it means no such id with these problems found
    printf("No matching car found with ID %d with any problem.\n", _input);
}
void readProblematicFile(struct problemCarS problematicCars[], int *problematicCount) {
    
    FILE *file = fopen("problematic_cars.txt", "r"); // opens with read mode
    if (file == NULL) {
        perror("Error opening problematic_cars.txt");
        return;
    }

    char line[100]; 
    while (fgets(line, sizeof(line), file) != NULL) {
        int id;
        char problems[100];

        // Use sscanf to extract information from the line
        if (sscanf(line, "VIMNUM %d PROBLEM %[^\n]", &id, problems) == 2) {
            // Check if there are problems
            if (strlen(problems) > 0) {
                problematicCars[*problematicCount].id = id;
                problematicCars[*problematicCount].weightProblem = 0; // Set weight to some default value
                problematicCars[*problematicCount].overheating = 0; // Set heating to some default value
                problematicCars[*problematicCount].brakingProblem = 0; // Set braking to some default value
                  problematicCars[*problematicCount].batteryProblem = 0;// Set battery to some default value
                // Update problematicCars based on the problems in the string
                if (strstr(problems, "Overheating") != NULL) { /// compares if finds some adds to the problematic this problem
                    problematicCars[*problematicCount].overheating = 1; // Set engine problem
                }

                if (strstr(problems, "WeightProblem") != NULL) {
                    problematicCars[*problematicCount].weightProblem = 1; // Set weight problem
                }
                if (strstr(problems, "BrakeIssue") != NULL) {
                    problematicCars[*problematicCount].brakingProblem = 1; // Set braking problem
                }
                if (strstr(problems, "BatteryProblem") != NULL) {
                    problematicCars[*problematicCount].batteryProblem = 1; 
                    // Set battarey problem
                }
                (*problematicCount)++;// add counter to know the size
            }
        }
    }

    fclose(file);// closes the file
}
void resetProblematicData(int *problematicCount) {
    *problematicCount = 0; // resets the counter
}
void Save( struct car cars[], int size){

     FILE *file = fopen("list.txt", "w"); // opens inital file list.txt with write mode and adds struct all the elements with the special order
    if (file == NULL) {
        perror("Error opening file");
        return ;
    }
     for (int i = 0; i < size; i++) {
        fprintf(file, "VINNUM %d MODELNAME %s WEIGHT %d MaxTemp %d BrakeIssue %d BattareyProblem %d\n",
                cars[i].vinNum, cars[i].Modelname, cars[i].weight, cars[i].engineMaxTemp, cars[i].brakingProblem,cars[i].batteryProblem);
    }

    fclose(file);// close
    printf(" Saved .....  \n");//notfiy user
}
void deleteEntryByVINNUM( struct car cars[],int vinToDelete) {

    // Create a temporary file
    FILE *file = fopen("list.txt", "r+");
    FILE *tempFile = fopen("temp_file.txt", "w");
    if (tempFile == NULL) {
        perror("Error creating temporary file");
        exit(1);
    }
    int i =0;
    // Read data from the original file and write to the temporary file, excluding the entry to delete
    while ( fscanf(file, "VINNUM %d MODELNAME %s WEIGHT %d MaxTemp %d BrakeIssue %d BattareyProblem %d\n",
                &cars[i].vinNum, cars[i].Modelname, &cars[i].weight, &cars[i].engineMaxTemp, &cars[i].brakingProblem,&cars[i].batteryProblem) == 6) {
        if (cars[i].vinNum != vinToDelete) {
            fprintf(tempFile, "VINNUM %d MODELNAME %s WEIGHT %d MaxTemp %d BrakeIssue %d BattareyProblem %d\n",
                cars[i].vinNum, cars[i].Modelname, cars[i].weight, cars[i].engineMaxTemp, cars[i].brakingProblem,cars[i].batteryProblem);
        }
        i++;
    }

    // Close files
    fclose(file);
    fclose(tempFile);

    // Replace the original file with the temporary file
    remove("list.txt");
    rename("temp_file.txt", "list.txt");
    printf("Removed VinNum %d element \n",vinToDelete);
}
void addEntry(struct car cars[] , int *size ) {
     char keyword[50];
    FILE *file = fopen("list.txt", "a");// append mode
    if (file == NULL) {
        perror("Error opening file");
        exit(1);
    }
    int newVinNum =-1;
    int found =0;
    printf("Please input new cars ViNum"); // asks from user vinum
    scanf("%d",&newVinNum);

    for(int i =0; i < *size;i++){
        if(newVinNum == cars[i].vinNum){
           
            found = 1; // if found with the same found make 1 
           
        }

    }

    if(found == 0){// if didnt found with the same vinum

        (*size)++; // adds the size 1
        cars[*size].vinNum = newVinNum; // asks from user input all the data
        printf("Enter Model Name: ");
        scanf("%s", cars[*size].Modelname);

        printf("Enter Weight:from (2500-3000) ");
        scanf("%d", &cars[*size].weight);

        printf("Enter Engine Max Temperature from (100 to 150): ");
        scanf("%d", &cars[*size].engineMaxTemp);

        printf("Enter Brake Issue (0 or 1): ");
        scanf("%d", &cars[*size].brakingProblem);

        printf("Enter Battarey Issue (0 or 1): ");
        scanf("%d", &cars[*size].batteryProblem);

        //adds to the list.txt file 
        fprintf(file, "VINNUM %d MODELNAME %s WEIGHT %d MaxTemp %d BrakeIssue %d BattareyProblem %d\n",
                cars[*size].vinNum, cars[*size].Modelname, cars[*size].weight, cars[*size].engineMaxTemp, cars[*size].brakingProblem,cars[*size].batteryProblem);
        
    }

    fclose(file);// close
    if(found == 1){
         printf("There exist car with the same Vinum\n");// notify repetiton
    }
    else{
         resetListSize(size); // then reset counter
         fileRead(cars,size,keyword); // read again to not lose the progres and user can print again to see that file was read
    }
}